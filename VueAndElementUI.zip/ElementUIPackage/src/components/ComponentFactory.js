
function isObject(arg) {
	return typeof arg === 'object' && arg !== null;
}

function extend(origin, add) {
	if(!add || !isObject(add)) return origin;

	var keys = Object.keys(add);
	var i = keys.length;
	while(i--) {

		origin[keys[i]] = add[keys[i]];
	}
	return origin;
};
function extendAll(origin, add) {
	if(!add || !isObject(add)) return origin;

	var keys = Object.keys(add);
	var i = keys.length;
	while(i--) {
		if(add.hasOwnProperty(keys[i])) {
			console.log([keys[i], typeof origin[keys[i]]]);
			var sourceKeyType = typeof origin[keys[i]];
			if(sourceKeyType === 'undefined' || sourceKeyType !== 'object') {
				origin[keys[i]] = add[keys[i]];
			} else {
				this.__extendAll(origin[keys[i]], add[keys[i]]);
			}
		}
	}
	return origin;
};

var DateTemplateFactorys = {
	buildMiniFormDataFactory: function(conf,data,rules) {
		var bindObject = {
			data: {},
			conf: {'inline':'true','size':'mini','label-width':'80px'},
			rules:{}
		};
		if(data){
			bindObject.data=data;
		}
		if(rules){
			bindObject.rules=rules;
		}
		extendAll(bindObject.conf,conf);
		return bindObject;
	},
	buildSmallFormDataFactory:function(conf,data,rules){
		var bindObject = {
			data: {},
			conf: {'inline':'true','size':'small','label-width':'100px'},
			rules:{}
		};
		if(data){
			bindObject.data=data;
		}
		if(rules){
			bindObject.rules=rules;
		}
		extendAll(bindObject.conf,conf);
		return bindObject;
	}
};

export default {
	name:'dataBuildFactory',
	factorys:DateTemplateFactorys
}
