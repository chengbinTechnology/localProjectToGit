<template>
	<el-container >
				<el-header id="nc_container_header" style="height:auto">
					 <slot name="header"></slot>
				</el-header>
				<el-main v-bind:style="{height:getMainHeight}">
					 <slot name="main"></slot>
				</el-main>
				<el-footer id="nc_container_footer" style="height:auto;">
					 <slot name="footer"></slot>
				</el-footer>
	</el-container>
</template>
<script>
	export default{
		data:function(){
			//console.log(this.bindStore);
			return {store:this.bindStore};
		},
		props: ['bindStore'],
		name:"new-cloud-container",
		computed:{
			getMainHeight:function(){
				var headerHeight=jQuery("#nc_container_header",this.$el).height();
				var fotterHeight=jQuery("#nc_container_footer",this.$el).height();
				var realHeight=this.store.mainHeight-headerHeight-fotterHeight;
				return realHeight+"px";
			}
		}
	}
</script>
<style>
.el-header{
	padding:0 2px;
}
.el-main{
	padding:0 2px;
}
.el-footer{
	padding:0 2px;
	height:auto;
}
</style>