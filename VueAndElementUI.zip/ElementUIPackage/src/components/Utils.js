var commonUtils = {
	/**
	 * 获取页面是可见高度
	 */
	getClientHeight: function() {
		return document.documentElement.clientHeight || document.body.clientHeight;
	},
	extend: function(origin, add) {
		if(!add || !isObject(add)) return origin;

		var keys = Object.keys(add);
		var i = keys.length;
		while(i--) {
			origin[keys[i]] = add[keys[i]];
		}
		return origin;
	}
};

/**
 * 工具方法类，定义一些常用的工具集
 */
export default {
	name: 'commonUtils',
	utils: commonUtils
}