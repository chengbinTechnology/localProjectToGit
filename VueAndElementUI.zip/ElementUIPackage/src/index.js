import Vue from 'vue'
import Element from 'element-ui'
import VueExpand from '@/components/VueExpand'
Vue.use(Element);
Vue.use(VueExpand);
import "@/theme/index.css"
import Commons from "@/components/Utils.js"
var windowStore = {
	debug: true,
	//容器需要初始的变量
	containerDataStruct: {
		clientHeight: 300, //这个值是页面的clientHeight高度，根据浏览器的缩放行为，可动态改变,改变后会传回到外部
		mainHeight: 200 //这个变量是容器的工作区域的高度，在容器中间区域放置的内容，需要把这个值传递进去，初始化或更新他们的高度
	},
	sexStore: {
		items: [{
			val: '20',
			text: '男'
		}, {
			val: '30',
			text: '女'
		}]
	},
	educationalStore: {
		items: [{
			val: 'bottom',
			text: '小学'
		}, {
			val: 'middle',
			text: '中学'
		}, {
			val: 'top',
			text: '大学'
		}, {
			val: 'up',
			text: '研究生'
		}]
	},
	hobbyStore: {
		items: [{
			val: 'wenxue',
			text: '文学'
		}, {
			val: 'xule',
			text: '娱乐'
		}, {
			val: 'tiyu',
			text: '体育'
		}, {
			val: 'shejiao',
			text: '社交'
		}]
	},
	selectStore: {
		items: [{
			val: '1',
			text: '特困'
		}, {
			val: '2',
			text: '一般'
		}, {
			val: '3',
			text: '贫困'
		}, {
			val: '4',
			text: '问题4'
		}]
	},
	cascaderStore: {

	}
};
var TabsStore = {
	tabs: [{
		title: '学生基本信息',
		name: 'menu1',
		link: 'http://www.tpsq.gov.cn/'
	}, {
		title: '普通组件',
		name: 'menu2',
		link: 'http://www.shangyikeji.com.cn'
	}, {
		title: '测试菜单',
		name: 'menu3',
		link: 'https://www.baidu.com/s?cl=3&tn=baidutop10&fr=top1000&wd=%E9%AB%98%E6%A0%A1%E8%80%81%E5%B8%88%E5%87%BA%E9%80%81%E5%91%BD%E9%A2%98&rsv_idx=2'
	}]
};

var FormsStore = {
	formData: {
		name: '校内足球活动',
		align: '20',
		educational: 'middle',
		hobby: ['xule'],
		selected: '',
		cascader: []
	}
};

window.dataStruct = {
	afterMounted: []
}
import newCloudContainer from "@/newCloudComponents/Container.vue"
import newCloudNavMenu from "@/newCloudComponents/NavMenu.vue"
import newCloudTabs from "@/newCloudComponents/Tabs.vue"
import newCloudForm from "@/newCloudComponents/Form/Form.vue"
import newCloudRadio from "@/newCloudComponents/Form/RadioGroup.vue"
import newCloudCheckBox from "@/newCloudComponents/Form/CheckBoxGroup.vue"
import newCloudSelect from "@/newCloudComponents/Form/Selected.vue"
import newCloudCascader from "@/newCloudComponents/Form/cascader.vue"
import newCloudTable from "@/newCloudComponnets/Table.vue"
Vue.component("new-cloud-table",newCloudTable);
Vue.component("new-cloud-container", newCloudContainer);
Vue.component("new-cloud-nav-menu", newCloudNavMenu);
Vue.component("new-cloud-tabs", newCloudTabs);
Vue.component("new-cloud-form", newCloudForm);
Vue.component("new-cloud-radio", newCloudRadio);
Vue.component("new-cloud-check-box", newCloudCheckBox);
Vue.component("new-cloud-select", newCloudSelect);
Vue.component("new-cloud-cascader", newCloudCascader);

var index = new Vue({
	el: "#index",
	data: {
		"ScopeStore": windowStore,
		"TabStore": TabsStore,
		"FormStore": FormsStore,
		"FormData": FormsStore.formData
	},
	mounted: function() { //对象创建以后，执行如下
		var height = Commons.utils.getClientHeight(); //修改页面加载完后的clientHeight
		this.ScopeStore.containerDataStruct.clientHeight = height; //把clientHeight回传到组件，进行高度变更
	},
	methods: {
		addTab: function() {
			this.TabStore.tabs.push({
				'title': 'Element-ui',
				'name': 'newTab1',
				'link': 'http://news.yongkao.com/jiaodian/41586.html'
			});
		},
		changeTest: function() {
			this.__axios.post('/user?ID=12345',FormsStore.formData)
				.then(function(response) {
					console.log(response);
				})
				.catch(function(error) {
					console.log(error);
			});
		}
	}
});