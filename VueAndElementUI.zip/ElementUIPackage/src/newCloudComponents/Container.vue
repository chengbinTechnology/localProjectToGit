<template>
	<el-container>
		<el-header id="nc_container_header" v-bind:style="{height:getHeaderHeight}">
			<slot name="header"></slot>
		</el-header>
		<el-main v-bind:style="{height:getMainHeight}">
			<slot name="main"></slot>
		</el-main>
		<el-footer id="nc_container_footer" v-bind:style="{height:getFooterHeight}">
			<slot name="footer"></slot>
		</el-footer>
	</el-container>
</template>
<script>
	export default {
		data: function() {
			//console.log(["initData:",this.dataStruct]);
			var store = {};
			if(typeof(this.dataStruct) !== "undefined") {
				store = this.dataStruct;
			}
			var default_store = {
				headerHeight: "auto",
				footerHeight: "auto",
				mainHeight: 500
			};
			this.__extend(default_store, store);
			this.__extend(store, default_store);
			return {
				"store": store
			}; //注意，这里一定要使用dataStruct才能生效绑定修改
		},
		props: ['dataStruct'],
		name: "newCloudContainer",
		computed: {
			//组件根究页面的实际clientHeight，自动更新mainClient的高度
			getMainHeight: function() {
				var realHeight = this.dataStruct.clientHeight;
				if(typeof this.$el !== "undefined") {
					var headerHeight=this.__selector(this.$el,"#nc_container_header").clientHeight;
					var fotterHeight=this.__selector(this.$el,"#nc_container_footer").clientHeight;
					realHeight = this.dataStruct.clientHeight - headerHeight - fotterHeight;
					this.store.mainHeight = realHeight;
				}
				return realHeight + "px";
			},
			getHeaderHeight: function() {

				if(this.store.headerHeight !== 'auto') {
					return this.store.headerHeight + "px";
				} else {
					return this.store.headerHeight;
				}
			},
			getFooterHeight: function() {
				if(this.store.footerHeight !== 'auto') {
					return this.store.footerHeight + "px";
				} else {
					return this.store.footerHeight;
				}
			}
		}
	}
</script>

<style>
	body {
		margin: auto;
		border: 1px;
	}
	
	.el-header {
		padding: 0 2px;
		/*border:solid 1px #F2F3F4;*/
	}
	
	.el-main {
		padding: 0 2px;
		/*border:solid 1px #F2F3F4;*/
	}
	
	.el-footer {
		padding: 0 2px;
		/*border:solid 1px #F2F3F4;*/
	}
</style>