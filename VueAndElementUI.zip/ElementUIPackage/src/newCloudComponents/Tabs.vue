<template>
	<el-tabs type="border-card" v-model="store.activeTab" closable v-bind:style="{height:mainHeight+'px'}" @tab-remove="removeTab">
		<template v-for="tab in store.tabs">
			<el-tab-pane v-bind:label="tab.title" :name="tab.name" v-bind:style="{height:getPanelHeight+'px'}">
				<template v-if="tab.link">
					<iframe v-bind:src="tab.link" style="height:100%;width:100%;border:none"></iframe>
				</template>
				<template v-else>
				</template>
			</el-tab-pane>
		</template>
	</el-tabs>
</template>s
<script>
	export default {
		name: 'newCloudTabs',
		props: ['dataStruct', 'mainHeight'],
		data: function() {
			//console.log(["paramData:", this.dataStruct]);
			var store = {};
			if(typeof(this.dataStruct) !== "undefined") {
				var store = this.dataStruct;
			}
			var default_store = {
				panelHeight: 0,
				activeTab: 'menu1'
			};
			this.__extend(default_store, store);
			this.__extend(store, default_store);
			//console.log(["inited", store]);
			return {
				"store": store
			}; //注意，这里一定要使用dataStruct才能生效绑定修改
		},
		computed: {
			getPanelHeight: function() {
				//console.log(this.mainHeight);
				return this.mainHeight - 40;
			}
		},
		mounted: function() {
			var nc_el = this.$el;
			window.dataStruct.afterMounted.push(function() {
				//console.log(jQuery(nc_el).height());
				//console.log(jQuery(".el-tabs__content", nc_el).height());
			});
		},
		methods: {
			removeTab(targetName) {
				let tabs = this.store.tabs;
				let activeName = this.store.activeTab;
				if(activeName === targetName) {
					tabs.forEach((tab, index) => {
						if(tab.name === targetName) {
							let nextTab = tabs[index + 1] || tabs[index - 1];
							if(nextTab) {
								activeName = nextTab.name;
							}
						}
					});
				}
				this.store.activeTab = activeName;
				this.store.tabs = tabs.filter(tab => tab.name !== targetName);
			}
		}
	}
</script>
<style>
	.el-tabs {
		/*height: 100%;*/
		height: 100%;
		overflow: auto;
	}
	
	.el-tabs__header {
		overflow: auto;
	}
	
	.el-tabs--border-card> .el-tabs__content {
		padding: 0px;
	}
	
	.el-tabs--border-card {
		border: none;
	}
</style>