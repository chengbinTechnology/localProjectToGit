<template>
	<el-menu :default-active="store.activeIndex" class="el-menu-demo" mode="horizontal">
		<template v-for="item in store.items" >
			<el-menu-item v-if="!item.items"  :key="item.idx" v-bind:index="item.idx">{{item.title}}</el-menu-item>
			<el-submenu v-else v-bind:index="item.idx" :key="item.idx" >
				<template slot="title">
					<i class="el-icon-tickets"></i>
					<span slot="title">{{item.title}}</span>
				</template>
				<el-menu-item v-for="childItem in item.items" v-bind:index="childItem.idx">{{childItem.title}}</el-menu-item>
			</el-submenu>
		</template>
	</el-menu>
</template>
<script>
	export default {
		name: "newCloudNavMenu",
		props: ['dataStruct'],
		data: function() {
			//console.log(["initData:", this.dataStruct]);
			var store = {};
			if(typeof(this.dataStruct) !== "undefined") {
				var store = this.dataStruct;
			}
			var default_store = {
				activeIndex: '3',
				items: [{
					idx: "1",
					title: "导航菜单",
					items:[{idx:'1-1',title:"子菜单一"},{idx:'1-2',title:"子菜单二"},{idx:'1-3',title:"子菜单三"}]
				}, {
					idx: "2",
					title: "我的导航"
				},{
					idx: "3",
					title: "自定义菜单的封装",
					items:[{idx:'3-1',title:"子菜单一"},{idx:'3-2',title:"子菜单二"},{idx:'3-3',title:"子菜单三"}]
				}],
				handlerClick: function() {
					console.log(this);
				}
			};
			this.__extend(default_store, store);
			this.__extend(store, default_store);
			//console.log(["inited", store]);
			return {
				"store": store
			}; //注意，这里一定要使用dataStruct才能生效绑定修改
		}
	}
</script>