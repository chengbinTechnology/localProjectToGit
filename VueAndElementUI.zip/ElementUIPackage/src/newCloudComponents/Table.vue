<template>
	<div id="dataTables" style="border:1px solid #F0F2F5">
		<new-cloud-form>
			<el-row :gutter="2">
				<el-col :span="18">
					<slot name="quickItem"></slot><slot name="moreItem"></slot>
				</el-col>
				<el-col :span="6">
					<slot name="buttons"></slot>
				</el-col>
			</el-row>
		</new-cloud-form>
		<el-table v-bind:data="store.datas" v-bind:size="store.config.size" v-bind:height="store.config.height" border style="width: 100%">
			<slot name="cloums"></slot>
		</el-table>
		<el-pagination :current-page="1" :page-sizes="[100, 200, 300, 400]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="400">
		</el-pagination>
	</div>
</template>
<script>
	export default {
		name: "newCloudTab",
		props: ['dataStruct'],
		data: function() {
			//console.log(["initData:", this.dataStruct]);
			var store = {};
			if(typeof(this.dataStruct) !== "undefined") {
				store = this.dataStruct;
			}
			var default_store = {
				name: "20",
				config: {
					size: 'mini',
					height: '200'
				}
			};
			this.__extendAll(default_store, store);
			this.__extend(store, default_store);
			console.log(["tableStore", store]);
			return {
				"store": store
			}; //注意，这里一定要使用dataStruct才能生效绑定修改
		},
		computed: {
			getMiniWidth: function(item) {
				//console.log(["item:",item]);
				return "";
			}
		},
		methods: {
			getMiniWidthMethod: function(item) {
				//console.log(item.miniWidth);
				if(item.miniWidth) {
					return item.miniWidth;
				}
				return "";
			}
		}
	}
</script>