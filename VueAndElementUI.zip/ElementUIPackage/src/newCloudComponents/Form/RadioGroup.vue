<template>
	<el-radio-group v-model="bindVal" v-bind:size="store.size">
		<el-radio-button v-for="radio in store.items" :key="radio.val" v-bind:label="radio.val">{{radio.text}}</el-radio-button>
	</el-radio-group>
</template>
<script>
	export default{
		props: ['dataStruct','bindForm','bindVar'], //通过prop来定义要绑定的对象，然后用v-model进行绑定。
		name: "newCloudRadio",
		data:function(){
			var inner_store = {};
			if(typeof(this.dataStruct) !== "undefined") {
				inner_store = this.dataStruct;
			}
			var default_store={
					items:[],
					size:'small'
			};
			this.__extend(default_store,inner_store);
			this.__extend(inner_store,default_store);
			return {
				"bindVal":this.bindForm[this.bindVar],
				"store":inner_store
			}
			//return store; //注意，这里一定要使用dataStruct才能生效绑定修改
		},
		watch:{
			bindVal:function(val){
				this.bindForm[this.bindVar]=val;
				//this.changeData();
				///console.log(this.bindForm);
			}
		}
	}
</script>