<template>
		<el-select placeholder="请选择" v-model="bindVal" :size="store.size">
			<el-option v-for="item in store.items" :key="item.val" :label="item.text" :value="item.val">
			</el-option>
		</el-select>
</template>
<script>
	export default {
		props: ['dataStruct', 'bindForm', 'bindVar'], //通过prop来定义要绑定的对象，然后用v-model进行绑定。
		name: "newCloudSelect",
		data: function() {
			var inner_store = {};
			if(typeof(this.dataStruct) !== "undefined") {
				inner_store = this.dataStruct;
			}
			var default_store = {
				items: [],
				size: 'small'
			};
			this.__extend(default_store, inner_store);
			this.__extend(inner_store, default_store);
			return {
				"bindVal": this.bindForm[this.bindVar],
				"store": inner_store
			}
		},
		watch: {
			bindVal: function(val) {
				this.bindForm[this.bindVar] = val;
				///console.log(this.bindForm);
			}
		}
	}
</script>