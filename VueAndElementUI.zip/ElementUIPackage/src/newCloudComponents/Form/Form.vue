<template>
	<el-form :model="formData" :inline="true" :rules="formRules" ref="dataForm" size="mini" label-width="70px">
	    <slot></slot>
	</el-form>
</template>
<script>
	export default{
		name:'nForm',
		data:function(){
			var store = {};
			if(typeof(this.dataStruct) !== "undefined") {
				var store = this.dataStruct;
			}
			var default_store={
					formData:{},
					formRules:{}
				};
			this.__extend(default_store,store);
			this.__extend(store,default_store);
			return store; //注意，这里一定要使用dataStruct才能生效绑定修改
		},
		props: ['dataStruct']
	}
</script>

<style>
	.el-form{
		padding:5px;
	}
	.el-form-item{
	    margin-bottom:3px;
	}
	.el-form-item--mini.el-form-item{
		margin-bottom:3px;
	}
</style>
