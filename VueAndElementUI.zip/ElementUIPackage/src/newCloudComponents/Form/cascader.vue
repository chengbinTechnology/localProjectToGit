<template>
	<el-cascader :options="store.items" :size="store.size" v-model="bindVal" @change="handleChange">
	</el-cascader>
</template>
<script>
	export default {
		props: ['dataStruct', 'bindForm', 'bindVar'], //通过prop来定义要绑定的对象，然后用v-model进行绑定。
		name: "newCloudCascader",
		data: function() {
			var inner_store = {};
			if(typeof(this.dataStruct) !== "undefined") {
				inner_store = this.dataStruct;
			}
			var default_store = {
				items: [{
					value: '10',
					label: '高校',
					children: [{
						value: '101',
						label: '内蒙古大学',
						children: [{
							value: '101-101',
							label: '计算机学院'
						}, {
							value: '101-102',
							label: '生物学院'
						}, {
							value: '101-103',
							label: '数学学院'
						}, {
							value: '101-104',
							label: '学工管理处'
						}]
					},{
						value: '102',
						label: '工业大学',
						children: [{
							value: '102-101',
							label: '通讯与信息工程学院'
						}, {
							value: '102-102',
							label: '工业设计学院'
						}, {
							value: '102-103',
							label: '建筑学院'
						}, {
							value: '102-104',
							label: '工程管理学院'
						}]
					}],
				},{
					value: '20',
					label: '高中',
					children: [{
						value: '201',
						label: '呼市二中',
						children: [{
							value: '201-201',
							label: '高三一班',
							disabled:"true"
						}, {
							value: '201-102',
							label: '高二一班'
						}, {
							value: '201-103',
							label: '高一一班'
						}, {
							value: '201-104',
							label: '高三二班'
						}]
					}],
				}],
				size: 'small'
			};
			//console.log(default_store);
			this.__extend(default_store, inner_store);
			this.__extend(inner_store, default_store);
			//console.log(inner_store);
			return {
				"bindVal": this.bindForm[this.bindVar],
				"store": inner_store
			}
		},
		watch: {
			bindVal: function(val) {
				this.bindForm[this.bindVar] = val;
			}
		},
		methods: {
			handleChange:function(val) {
				console.log(val);
			}
		}
	}
</script>