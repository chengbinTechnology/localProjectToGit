package source.chengbin.info.common.bean;

public class JXSLRowData {

	
	public JXSLRowData(Object value){
		this.value=value;
	}
	
	private Object value;

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

}
