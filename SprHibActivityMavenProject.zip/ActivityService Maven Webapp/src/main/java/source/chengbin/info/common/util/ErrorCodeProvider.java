package source.chengbin.info.common.util;

public class ErrorCodeProvider {
    public final static String E0001="e0001"; //不能在同一区间重复发起报账单
    public final static String E0002="e0002"; //该项业务当前为不开放状态，请联系管理人员
    public final static String E0003="e0003";
    public final static String E0004="e0004";
    public final static String E0005="e0005";
}
