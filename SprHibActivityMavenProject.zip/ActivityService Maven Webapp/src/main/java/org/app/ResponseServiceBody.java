package org.app;

public interface ResponseServiceBody {
    public Object getContent();
}
